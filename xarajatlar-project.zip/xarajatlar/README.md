# Xarajatlarim

Kundalik xarajatlarni yozib boradigan oddiy veb-ilova. Ma'lumotlar brauzerda (localStorage) saqlanadi.

## Ishga tushirish
`index.html` faylini brauzerda oching.

## GitHub Pages
Settings → Pages → Deploy from a branch → `main` → Save.
